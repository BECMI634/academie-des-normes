const state = {
  points: 0,
  badges: [],
  level: 1,
  completed: [],
  mistakes: {},
};

const screens = document.querySelectorAll('.screen');
const navButtons = document.querySelectorAll('.nav-btn');
const levelContainer = document.getElementById('levelContainer');
const teacherTable = document.getElementById('teacherTable');
const summaryBox = document.getElementById('summaryBox');

function goTo(screenId) {
  screens.forEach(s => s.classList.toggle('active', s.id === `screen-${screenId}`));
  navButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.screen === screenId));
}

navButtons.forEach(btn => btn.addEventListener('click', () => goTo(btn.dataset.screen)));
document.querySelectorAll('[data-go]').forEach(btn => btn.addEventListener('click', () => goTo(btn.dataset.go)));
document.getElementById('startAdventure').addEventListener('click', () => goTo('map'));

function updateStats() {
  document.getElementById('statLevel').textContent = state.level;
  document.getElementById('statPoints').textContent = state.points;
  document.getElementById('statBadges').textContent = state.badges.length;
  renderSummary();
  renderTeacherRow();
}

function addPoints(points) {
  state.points += points;
  updateStats();
}

function unlockLevel(n) {
  if (n === 2) {
    const btn = document.getElementById('level2Btn');
    btn.classList.remove('locked');
    btn.classList.add('unlocked');
  }
  if (n === 3) {
    const btn = document.getElementById('level3Btn');
    btn.classList.remove('locked');
    btn.classList.add('unlocked');
  }
}

function addBadge(name) {
  if (!state.badges.includes(name)) state.badges.push(name);
  updateStats();
}

function renderSummary() {
  const playerName = document.getElementById('playerName').value || 'Élève';
  if (state.completed.length === 0) {
    summaryBox.innerHTML = '<p>Aucune mission terminée pour le moment.</p>';
    return;
  }
  summaryBox.innerHTML = `
    <p><strong>${playerName}</strong></p>
    <p>Progression : ${Math.min(state.completed.length * 33, 100)} %</p>
    <p>Niveaux validés : ${state.completed.join(', ')}</p>
    <p>Badges : ${state.badges.join(', ') || 'aucun'}</p>
  `;
}

function renderTeacherRow() {
  const playerName = document.getElementById('playerName').value || 'Élève test';
  const weakness = Object.entries(state.mistakes).sort((a,b) => b[1]-a[1])[0]?.[0] || '—';
  const progress = `${Math.min(state.completed.length * 33, 100)} %`;
  teacherTable.innerHTML = `
    <tr><td>${playerName}</td><td>${progress}</td><td>${weakness}</td></tr>
    <tr><td>Emma</td><td>78 %</td><td>Espaces avec %</td></tr>
    <tr><td>Lucas</td><td>63 %</td><td>Deux-points</td></tr>
  `;
}

document.getElementById('playerName').addEventListener('input', renderTeacherRow);

function loadLevel(level) {
  if (level > 1 && !state.completed.includes(level - 1)) return;
  const tpl = document.getElementById(`tpl-level-${level}`);
  levelContainer.innerHTML = '';
  levelContainer.appendChild(tpl.content.cloneNode(true));

  if (level < 3) {
    const options = levelContainer.querySelectorAll('.option');
    const correctIndex = Number(levelContainer.querySelector('.options').dataset.correct);
    const feedback = levelContainer.querySelector('.feedback');
    options.forEach((btn, index) => {
      btn.addEventListener('click', () => {
        options.forEach(b => b.disabled = true);
        const ok = index === correctIndex;
        btn.classList.add(ok ? 'correct' : 'wrong');
        options[correctIndex].classList.add('correct');
        if (ok) {
          feedback.className = 'feedback success';
          feedback.innerHTML = level === 1
            ? '✔ Bonne réponse. En français, une espace précède et suit les signes doubles : ; ? !'
            : '✔ Bonne réponse. On écrit « Montant : 25 € » avec une espace avant les deux-points et avant le symbole €.';
          addPoints(10);
          if (!state.completed.includes(level)) state.completed.push(level);
          state.level = Math.max(state.level, level + 1);
          if (level === 1) { unlockLevel(2); addBadge('Typographe débutant'); }
          if (level === 2) { unlockLevel(3); addBadge('Archiviste'); }
        } else {
          feedback.className = 'feedback error';
          feedback.innerHTML = '✘ Ce n’est pas la bonne réponse. Relisez la règle d’espacement visée.';
          state.mistakes[level === 1 ? 'Ponctuation double' : 'Symboles € et %'] = (state.mistakes[level === 1 ? 'Ponctuation double' : 'Symboles € et %'] || 0) + 1;
          updateStats();
        }
      });
    });
  } else {
    const feedback = levelContainer.querySelector('.feedback');
    const marks = levelContainer.querySelectorAll('.mark');
    marks.forEach(mark => mark.addEventListener('click', () => mark.classList.toggle('selected')));
    document.getElementById('validateMarks').addEventListener('click', () => {
      const allCorrect = [...marks].every(mark => mark.classList.contains('selected') === (mark.dataset.answer === 'true'));
      if (allCorrect) {
        feedback.className = 'feedback success';
        feedback.innerHTML = '✔ Mission réussie. Corrections attendues : « Objet : », « Madame, Monsieur » et « 25 % ».';
        addPoints(20);
        if (!state.completed.includes(3)) state.completed.push(3);
        state.level = Math.max(state.level, 4);
        addBadge('Maître du courrier');
      } else {
        feedback.className = 'feedback error';
        feedback.innerHTML = '✘ Certaines erreurs n’ont pas été repérées ou un bon élément a été coché.';
        state.mistakes['Lettre professionnelle'] = (state.mistakes['Lettre professionnelle'] || 0) + 1;
        updateStats();
      }
    });
  }
  updateStats();
}

document.querySelectorAll('.level-card').forEach(btn => {
  btn.addEventListener('click', () => {
    const level = Number(btn.dataset.level);
    if (btn.classList.contains('locked')) return;
    loadLevel(level);
  });
});

const trainingBank = {
  'double-signs': [
    { prompt: 'Choisissez la forme correcte :', options: ['Attention: danger !', 'Attention : danger !'], correct: 1, explanation: 'Les deux-points prennent une espace avant et après.' },
    { prompt: 'Choisissez la forme correcte :', options: ['Tu viens ?', 'Tu viens?'], correct: 0, explanation: 'Le point d’interrogation est précédé d’une espace.' },
  ],
  'symbols': [
    { prompt: 'Quelle écriture est correcte ?', options: ['25%', '25 %'], correct: 1, explanation: 'Une espace sépare le nombre du symbole %.' },
    { prompt: 'Quelle écriture est correcte ?', options: ['19€', '19 €'], correct: 1, explanation: 'Une espace sépare le nombre du symbole €.' },
  ],
  'parentheses': [
    { prompt: 'Quelle écriture est correcte ?', options: ['Salle (A12 )', 'Salle (A12)'], correct: 1, explanation: 'Pas d’espace avant la parenthèse fermante.' },
  ],
  'time': [
    { prompt: 'Quelle écriture est correcte ?', options: ['14 : 30', '14:30'], correct: 1, explanation: 'Dans ce prototype, les heures s’écrivent ici sans espace autour du deux-points.' },
  ],
};

document.getElementById('generateTraining').addEventListener('click', () => {
  const topic = document.getElementById('trainingTopic').value;
  const box = document.getElementById('trainingBox');
  const item = trainingBank[topic][Math.floor(Math.random() * trainingBank[topic].length)];
  box.innerHTML = `
    <p><strong>${item.prompt}</strong></p>
    <div class="options training-options"></div>
    <div class="feedback"></div>
  `;
  const optionsWrap = box.querySelector('.training-options');
  const feedback = box.querySelector('.feedback');
  item.options.forEach((text, index) => {
    const btn = document.createElement('button');
    btn.className = 'option';
    btn.textContent = text;
    btn.addEventListener('click', () => {
      [...optionsWrap.children].forEach(b => b.disabled = true);
      const ok = index === item.correct;
      btn.classList.add(ok ? 'correct' : 'wrong');
      optionsWrap.children[item.correct].classList.add('correct');
      feedback.className = ok ? 'feedback success' : 'feedback error';
      feedback.textContent = (ok ? '✔ ' : '✘ ') + item.explanation;
      if (ok) addPoints(5); else {
        state.mistakes[document.getElementById('trainingTopic').selectedOptions[0].textContent] = (state.mistakes[document.getElementById('trainingTopic').selectedOptions[0].textContent] || 0) + 1;
        updateStats();
      }
    });
    optionsWrap.appendChild(btn);
  });
});

updateStats();
